<?php

namespace App\Http\Controllers;

use App\Http\Requests\ExamRequest;
use App\Models\ExameTypeTbl;
use App\Models\Exams;
use App\Models\McqTbl;
use App\Models\TrueFalseTbl;
use Illuminate\Http\Request;

class ExamController extends Controller
{

    public function index(){
        $exams = Exams::query()->get();
        return view('index')->with('exams',$exams);
    }

    public function create_exam(){
        $exam_type = ExameTypeTbl::query()->get();
        return view('create_exam')->with('exam_types',$exam_type);
    }

    public function store_exam(ExamRequest $request){
        Exams::query()->create([
            'exam_id' => $request->exam_id,
            'exam_title' => $request->exam_title,
            'exam_type' => $request->exam_type,
        ]);

        return redirect()->route('exam.index');
    }

    public function edit_exam($id){
        $exam_type = ExameTypeTbl::query()->get();
        $exam = Exams::query()->find($id);
        return view('edit_exam')->with('exam_types',$exam_type)->with('exam',$exam);
    }

    public function update_exam($id,ExamRequest $request){
        $exam = Exams::query()->find($id);
        $exam->update([
            'exam_id' => $request->exam_id,
            'exam_title' => $request->exam_title,
            'exam_type' => $request->exam_type,
        ]);

        return redirect()->route('exam.index');
    }

    public function delete_exam($id){
        $exam = Exams::query()->find($id);
        $exam->delete();
        return redirect()->route('exam.index');
    }

    public function create_qus($exam_id){
        $exam = Exams::query()->find($exam_id);
        return view('create_qus')->with('exam',$exam);
    }

    public function store_mcq_que(Request $request){
        McqTbl::query()->create([
            'qtitle' => $request->qtitle,
            'choice_1' => $request->choice_1,
            'choice_2' => $request->choice_2,
            'choice_3' => $request->choice_3,
            'choice_4' => $request->choice_4,
            'answer' => $request->answer,
            'exam_id' => $request->exam_id,
        ]);
        return redirect()->route('exam.index');

    }

    public function store_true_que(Request $request){
        TrueFalseTbl::query()->create([
            'qtitle' => $request->qtitle,
            'answer' => $request->answer,
            'exam_id' => $request->exam_id,
        ]);
        return redirect()->route('exam.index');
    }

    public function show_ques($exam_id){
        $exam = Exams::query()->find($exam_id);
        return view('show')->with('exam',$exam);
    }
}
