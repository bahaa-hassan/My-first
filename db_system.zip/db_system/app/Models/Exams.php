<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exams extends Model
{
    use HasFactory;
    protected $table = 'exams';
    protected $fillable = [
        'exam_id',
        'exam_title',
        'exam_type'
    ];

    public $timestamps = true;

    public function mcqs(){
        return $this->hasMany(McqTbl::class,'exam_id','id');
    }
    public function trueAndFalse(){
        return $this->hasMany(TrueFalseTbl::class,'exam_id','id');
    }
}
