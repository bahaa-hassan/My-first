<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class McqTbl extends Model
{
    use HasFactory;

    protected $table = 'mcq_tbls';
    protected $fillable = [
        'qtitle',
        'choice_1',
        'choice_2',
        'choice_3',
        'choice_4',
        'answer',
        'exam_id',
    ];

    public $timestamps = true;

    public function exam(){
        return $this->belongsTo(Exams::class,'exam_id','id');

    }

}
