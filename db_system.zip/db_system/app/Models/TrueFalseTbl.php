<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrueFalseTbl extends Model
{
    use HasFactory;

    protected $table = 'true_false_tbls';
    protected $fillable = [
        'qtitle',
        'answer',
        'exam_id',
    ];

    public $timestamps = true;

    public function exam(){
        return $this->belongsTo(Exams::class,'exam_id','id');

    }

}
