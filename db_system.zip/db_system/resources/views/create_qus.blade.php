<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام ادارة الامتحان</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{asset('css/all.min.css')}}">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="left-content">
                <h3 class="text-end">اضافة اسئلة جديد</h3>
            </div>
        </div>

        <div class="col-lg-6">
        </div>
    </div>
    <hr>
    <div>
        <p style="color:gray">يرجى ملء هذا النموذج لاضافة امتحان جديد</p>.
@if($exam->exam_type == 2)
        <form action="{{route('exam.store_mcq_que')}}" method="post">
            @csrf
            <input type="hidden" value="{{$exam->id}}" name="exam_id">
            <div class="mb-3">
                <label for="exam_id" class="form-label">رقم الامتحان</label>
                <input type="text" class="form-control" disabled value="{{$exam->exam_id}}" id="exam_id" name="">
            </div>

            <div class="mb-3">
                <label for="qtitle" class="form-label">السؤال</label>
                <input type="text" class="form-control" id="qtitle" name="qtitle">
            </div>

            <div class="mb-3">
                <label for="choice_1" class="form-label">السؤال الاول</label>
                <input type="text" class="form-control" id="choice_1" name="choice_1">
            </div>
            <div class="mb-3">
                <label for="choice_2" class="form-label">السؤال الثاني</label>
                <input type="text" class="form-control" id="choice_2" name="choice_2">
            </div>

            <div class="mb-3">
                <label for="choice_3" class="form-label">السؤال الثالث</label>
                <input type="text" class="form-control" id="choice_3" name="choice_3">
            </div>

            <div class="mb-3">
                <label for="choice_4" class="form-label">السؤال الرابع</label>
                <input type="text" class="form-control" id="choice_4" name="choice_4">
            </div>

            <div class="mb-3">
                <label for="chose4" class="form-label">الاجابة الصحيحة</label>
                <input type="text" class="form-control" id="answer" name="answer">
            </div>

            <input type="submit" name="add_mcq" class="btn btn-success" value="حفظ">
            <a href="#" class="btn btn-default border">العاء</a>
        </form>

        @else

        <form action="{{route('exam.store_true_que')}}" method="post">
            @csrf
            <input type="hidden" value="{{$exam->id}}" name="exam_id">
            <div class="mb-3">
                <label for="exam_id" class="form-label">رقم الامتحان</label>
                <input type="text" class="form-control"  disabled value="{{$exam->exam_id}}" id="exam_id" name="exam_id">
            </div>

            <div class="mb-3">
                <label for="qtitle" class="form-label">السؤال</label>
                <input type="text" class="form-control" id="qtitle" name="qtitle">
            </div>

            <div class="mb-3">
                <label for="exam_name" class="form-label">الاجابة</label>
                <select type="text" class="form-select" id="answer" name="answer">
                    <option value="-1">اخترالاجابة </option>
                    <option value="0">صح</option>
                    <option value="1">خطأ</option>
                </select>
            </div>

            <input type="submit"  class="btn btn-success" value="حفظ">
            <a href="#" class="btn btn-default border">العاء</a>

        </form>

        @endif

    </div>




</div>

<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('js/all.min.js')}}"></script>

</body>
</html>
