<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام ادارة الامتحانات</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{asset('css/all.min.css')}}">
    <style>
        p{
            color:gray
        }

    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>نظام ادارة الامتحانات</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">

            </div>
        </div>
    </div>
    <hr>

    <div>
        <p>يرجى ملء  النموذج</p>
        <form action="{{route('exam.update_exam',$exam->id)}}" method="post">
            @csrf
            <div>
                <label for="exam_id" class="form-label">رقم الامتحان</label>
                <input type="text" class="form-control" name="exam_id" value="{{$exam->exam_id}}" id="exam_id">
                <span class="text-danger"></span>
            </div>
            <div>
                <label for="exam_title" class="form-label">اسم الامتحان</label>
                <input type="text" class="form-control" name="exam_title" value="{{$exam->exam_title}}" id="exam_title">
                <span class="text-danger"></span>
            </div>
            <div>
                <label for="exam_type" class="form-label">نوع الامتحان</label>
                <select type="text" class="form-select" name="exam_type" id="exam_type">
                    @foreach($exam_types as $exam_type)
                        <option value="{{$exam_type->id}}" @if($exam_type->id == $exam->exam_type) selected @endif>{{$exam_type->name}}</option>
                    @endforeach
                </select>
            </div>
            <input type="submit"  class="btn btn-success" value="حفظ">
            <input type="button" class="btn" value="الغاء">
        </form>
    </div>


</div>

<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('js/all.min.js')}}"></script>
</body>
</html>
