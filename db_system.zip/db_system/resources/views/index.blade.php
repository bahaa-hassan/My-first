
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام ادارة الامتحانات</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{asset('css/all.min.css')}}">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>نظام ادارة الامتحانات</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">
                <a href="{{route('exam.create_exam')}}" title="My NAMe" class="btn btn-success">اضافة امتحان جديد</a>
            </div>
        </div>
    </div>
    <hr>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>رقم الامتحان</th>
            <th>اسم الامتحان</th>
            <th>نوع الامتحان</th>
            <th>الاجراءات</th>
        </tr>

        @foreach($exams as $exam)
        <tr>
            <td>{{$exam->id}}</td>
            <td>{{$exam->exam_id}}</td>
            <td>{{$exam->exam_title}}</td>
            <td>{{$exam->exam_type}}</td>
            <td>
                <a href="{{route('exam.show_ques',$exam->id)}}"><i class="fa-solid fa-eye"></i></a>
                &nbsp; &nbsp;
                <a href="{{route('exam.edit_exam',$exam->id)}}"><i class="fa-solid fa-pen-to-square"></i></a>
                &nbsp; &nbsp;
                <a href="{{route('exam.create_qus',$exam->id)}}"><i class="fa-solid fa-plus"></i></a>
                &nbsp; &nbsp;
                <a href="{{route('exam.delete_exam',$exam->id)}}"><i class="fa-solid fa-trash"></i></a>
            </td>
        </tr>
        @endforeach
    </table>
</div>

<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>

<script src="{{asset('js/all.min.js')}}"></script>
</body>
</html>
