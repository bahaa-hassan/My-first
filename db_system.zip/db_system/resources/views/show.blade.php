<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عرض اسئلة الامتحان</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{asset('css/all.min.css')}}">
    <style>
        p{
            color:gray
        }

    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>عرض اسئلة الامتحان</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">

            </div>
        </div>
    </div>
    <hr>

    <div class="row">
        <div class="col-md-4">
            <h5>رقم الامتحان : <span> {{$exam->exam_id}} </span> </h5>
        </div>

        <div class="col-md-4">
            <h5>اسم الامتحان : <span>{{$exam->exam_title}}  </span></h5>
        </div>
        <div class="col-md-4">
            <h5>نوع الامتحان : <span>  {{$exam->exam_type}}</span></h5>
        </div>
    </div>

    <div>
        <h3>الاسئلة</h3>
@if($exam->exam_type == 2)
        <div>
            <ol>

        @foreach($exam->mcqs as $mcq)
                <li>{{$mcq->qtitle}} <br>
                    <ol type="A">
                        <li @if($mcq->answer == 1)  style="color: green;font-weight: bolder;"@endif>{{$mcq->choice_1}} </li>
                        <li @if($mcq->answer == 2)  style="color: green;font-weight: bolder;"@endif> {{$mcq->choice_2}}</li>
                        <li @if($mcq->answer == 3)  style="color: green;font-weight: bolder;"@endif>{{$mcq->choice_3}} </li>
                        <li @if($mcq->answer == 4)  style="color: green;font-weight: bolder;"@endif> {{$mcq->choice_4}}</li>
                    </ol>
                </li>
         @endforeach


            </ol>
        </div>


@else

            <div>
                <ol>

                @foreach($exam->trueAndFalse as $qus)
                    <li>{{$qus->qtitle}} <br>
                        <ol type="A">
                            <li ><input @if($qus->answer == 0) checked @endif type="radio" disabled > صح</li>
                            <li ><input @if($qus->answer == 1) checked @endif type="radio" disabled > خطأ</li>
                        </ol>
                    </li>
               @endforeach
                </ol>
            </div>
        @endif
    </div>


</div>

<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>

<script src="{{asset('js/all.min.js')}}"></script>
</body>
</html>
