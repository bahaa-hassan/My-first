<?php

use App\Http\Controllers\ExamController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('index');
//});

Route::get('/',[ExamController::class,'index'])->name('exam.index');
Route::get('/create-exam',[ExamController::class,'create_exam'])->name('exam.create_exam');
Route::post('/store-exam',[ExamController::class,'store_exam'])->name('exam.store_exam');
Route::get('/edit-exam/{id}',[ExamController::class,'edit_exam'])->name('exam.edit_exam');
Route::post('/update-exam/{id}',[ExamController::class,'update_exam'])->name('exam.update_exam');
Route::get('/delete-exam/{id}',[ExamController::class,'delete_exam'])->name('exam.delete_exam');

Route::get('/create-que/{exam_id}',[ExamController::class,'create_qus'])->name('exam.create_qus');
Route::post('/store-mcq_que',[ExamController::class,'store_mcq_que'])->name('exam.store_mcq_que');
Route::post('/store-true_que',[ExamController::class,'store_true_que'])->name('exam.store_true_que');


Route::get('/show-ques/{exam_id}',[ExamController::class,'show_ques'])->name('exam.show_ques');
