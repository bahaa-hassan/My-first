<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام ادارة الامتحانات</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <style>
        p{
            color:gray
        }

    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>نظام ادارة الامتحانات</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">

            </div>
        </div>
    </div>
    <hr>

    <div>
        <p>يرجى ملء  النموذج</p>
        <form action="<?php echo e(route('exam.update_exam',$exam->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <label for="exam_id" class="form-label">رقم الامتحان</label>
                <input type="text" class="form-control" name="exam_id" value="<?php echo e($exam->exam_id); ?>" id="exam_id">
                <span class="text-danger"></span>
            </div>
            <div>
                <label for="exam_title" class="form-label">اسم الامتحان</label>
                <input type="text" class="form-control" name="exam_title" value="<?php echo e($exam->exam_title); ?>" id="exam_title">
                <span class="text-danger"></span>
            </div>
            <div>
                <label for="exam_type" class="form-label">نوع الامتحان</label>
                <select type="text" class="form-select" name="exam_type" id="exam_type">
                    <?php $__currentLoopData = $exam_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($exam_type->id); ?>" <?php if($exam_type->id == $exam->exam_type): ?> selected <?php endif; ?>><?php echo e($exam_type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <input type="submit"  class="btn btn-success" value="حفظ">
            <input type="button" class="btn" value="الغاء">
        </form>
    </div>


</div>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\db_system\resources\views/edit_exam.blade.php ENDPATH**/ ?>