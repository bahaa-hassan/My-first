<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عرض اسئلة الامتحان</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <style>
        p{
            color:gray
        }

    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>عرض اسئلة الامتحان</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">

            </div>
        </div>
    </div>
    <hr>

    <div class="row">
        <div class="col-md-4">
            <h5>رقم الامتحان : <span> <?php echo e($exam->exam_id); ?> </span> </h5>
        </div>

        <div class="col-md-4">
            <h5>اسم الامتحان : <span><?php echo e($exam->exam_title); ?>  </span></h5>
        </div>
        <div class="col-md-4">
            <h5>نوع الامتحان : <span>  <?php echo e($exam->exam_type); ?></span></h5>
        </div>
    </div>

    <div>
        <h3>الاسئلة</h3>
<?php if($exam->exam_type == 2): ?>
        <div>
            <ol>

        <?php $__currentLoopData = $exam->mcqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($mcq->qtitle); ?> <br>
                    <ol type="A">
                        <li <?php if($mcq->answer == 1): ?>  style="color: green;font-weight: bolder;"<?php endif; ?>><?php echo e($mcq->choice_1); ?> </li>
                        <li <?php if($mcq->answer == 2): ?>  style="color: green;font-weight: bolder;"<?php endif; ?>> <?php echo e($mcq->choice_2); ?></li>
                        <li <?php if($mcq->answer == 3): ?>  style="color: green;font-weight: bolder;"<?php endif; ?>><?php echo e($mcq->choice_3); ?> </li>
                        <li <?php if($mcq->answer == 4): ?>  style="color: green;font-weight: bolder;"<?php endif; ?>> <?php echo e($mcq->choice_4); ?></li>
                    </ol>
                </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ol>
        </div>


<?php else: ?>

            <div>
                <ol>

                <?php $__currentLoopData = $exam->trueAndFalse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($qus->qtitle); ?> <br>
                        <ol type="A">
                            <li ><input <?php if($qus->answer == 0): ?> checked <?php endif; ?> type="radio" disabled > صح</li>
                            <li ><input <?php if($qus->answer == 1): ?> checked <?php endif; ?> type="radio" disabled > خطأ</li>
                        </ol>
                    </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        <?php endif; ?>
    </div>


</div>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\db_system\resources\views/show.blade.php ENDPATH**/ ?>