
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام ادارة الامتحانات</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="right-content">
                <h3>نظام ادارة الامتحانات</h3>
            </div>
        </div>
        <div class="col-md-6">
            <div class="left-content text-start">
                <a href="<?php echo e(route('exam.create_exam')); ?>" title="My NAMe" class="btn btn-success">اضافة امتحان جديد</a>
            </div>
        </div>
    </div>
    <hr>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>رقم الامتحان</th>
            <th>اسم الامتحان</th>
            <th>نوع الامتحان</th>
            <th>الاجراءات</th>
        </tr>

        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($exam->id); ?></td>
            <td><?php echo e($exam->exam_id); ?></td>
            <td><?php echo e($exam->exam_title); ?></td>
            <td><?php echo e($exam->exam_type); ?></td>
            <td>
                <a href="<?php echo e(route('exam.show_ques',$exam->id)); ?>"><i class="fa-solid fa-eye"></i></a>
                &nbsp; &nbsp;
                <a href="<?php echo e(route('exam.edit_exam',$exam->id)); ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                &nbsp; &nbsp;
                <a href="<?php echo e(route('exam.create_qus',$exam->id)); ?>"><i class="fa-solid fa-plus"></i></a>
                &nbsp; &nbsp;
                <a href="<?php echo e(route('exam.delete_exam',$exam->id)); ?>"><i class="fa-solid fa-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\db_system\resources\views/index.blade.php ENDPATH**/ ?>